# Magic Ball — Xiaomi Smart Band 10

Version 1.2.0 / versionCode 4.

Changes in 1.2:
- much larger ball and answer window;
- larger triangle and adaptive answer text;
- multi-stage shake / swirl / reveal / glow animation;
- requires several shake peaks before revealing an answer;
- classic + meme + rude answers are mixed together;
- much larger answer pool;
- screen keep-on window extended to 120 seconds;
- no mode selector and no extra UI labels.

Build with the official Xiaomi `aiot-toolkit`:

```bash
npm install
npm run check
npm run build
```
