# Magic Ball — Xiaomi Smart Band 10

Версия 1.0.1 / versionCode 2.

Это исходный проект Xiaomi Vela JS Quick App для Xiaomi Smart Band 10.
Он собирается **официальным `aiot-toolkit`**, а GitHub Actions автоматически отдаёт готовый `.rpk` как Artifact.

## Что внутри

- тап по шару;
- встряхивание через `@system.sensor` / `subscribeAccelerometer`;
- короткая вибрация;
- классический режим;
- мемный режим;
- редкие секретные ответы;
- интерфейс под 212×520.

## Автоматическая сборка на GitHub

1. Создай новый пустой репозиторий GitHub.
2. Загрузи в него **содержимое этой папки**, включая скрытую папку `.github`.
3. Открой вкладку **Actions**.
4. Выбери **Build Magic Ball RPK**.
5. Нажми **Run workflow**.
6. После зелёной галочки открой запуск и скачай Artifact **magic-ball-mi-band-10-rpk**.
7. Внутри ZIP будет настоящий `.rpk`, собранный командой `aiot build`.
8. Этот `.rpk` устанавливай в AstroBox → Xiaomi Smart Band 10 → «Быстрое приложение» → установить.

## Локальная сборка

```bash
npm install
npm run check
npm run build
```

Готовый `.rpk` появится в `dist/`.

## Важно

Не используй старый вручную упакованный `com.magicball.band10.debug.1.0.0.rpk`.
Для повторной установки этой версии `versionCode` уже повышен до 2.
