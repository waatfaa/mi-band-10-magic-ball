# Magic Oval for Xiaomi Smart Band 10

Version 1.4.0 / versionCode 6.

Concept: the whole 212×520 watch screen is the magic oval. The answer uses almost the full oval area, with no small central triangle. Shake detection requires multiple peaks before reveal. Animation is intentionally lightweight: opacity + small scale only.

Build with Xiaomi `aiot-toolkit 2.0.5` using `npm run build`.
