const fs = require('fs')
const path = require('path')

function fail(message) {
  console.error('ERROR: ' + message)
  process.exit(1)
}

const root = path.resolve(__dirname, '..')
const manifestPath = path.join(root, 'src', 'manifest.json')
const appPath = path.join(root, 'src', 'app.ux')
const pagePath = path.join(root, 'src', 'pages', 'index', 'index.ux')
const iconPath = path.join(root, 'src', 'common', 'images', 'icon.png')

for (const p of [manifestPath, appPath, pagePath, iconPath]) {
  if (!fs.existsSync(p)) fail('Missing file: ' + path.relative(root, p))
}

const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
if (manifest.package !== 'com.magicball.band10') fail('Unexpected package name')
if (manifest.versionCode < 9) fail('versionCode must be at least 9')
if (manifest.versionName !== '1.7.0') fail('versionName must be 1.7.0')
if (!manifest.config || manifest.config.designWidth !== 212) fail('designWidth must be 212')

const features = (manifest.features || []).map(x => x.name)
for (const required of ['system.sensor', 'system.vibrator', 'system.brightness']) {
  if (!features.includes(required)) fail('Missing feature: ' + required)
}

const page = fs.readFileSync(pagePath, 'utf8')
if (!page.includes("import sensor from '@system.sensor'")) fail('Sensor import not found')
if (!page.includes("import vibrator from '@system.vibrator'")) fail('Vibrator import not found')
if (!page.includes("import brightness from '@system.brightness'")) fail('Brightness import not found')
if (!page.includes('subscribeAccelerometer')) fail('Accelerometer subscription not found')
if (!page.includes('setKeepScreenOn')) fail('Screen keep-on call not found')
if (!page.includes('REQUIRED_SHAKE_PEAKS = 5')) fail('Multi-shake logic not found')
if (!page.includes('SCREEN_HOLD_MS = 120000')) fail('Extended screen hold not found')
if (!page.includes('width: 212px')) fail('Full-screen width not found')
if (!page.includes('height: 520px')) fail('Full-screen height not found')
if (!page.includes('magic-cloud')) fail('Persistent cloud not found')
if (!page.includes('cloud-answer')) fail('Persistent answer cloud state not found')
if (!page.includes('.answer-zone')) fail('Full-screen answer wrapper not found')
if (!page.includes('justify-content: center')) fail('Centered answer layout not found')
if (!page.includes('AnswerFade')) fail('Minimal answer fade animation not found')
if (page.includes('AnswerTextIn')) fail('Text transform animation must remain removed')
if (page.includes('answer-triangle')) fail('Triangle UI must not be used')
if (!page.includes('ДА ЁБАНЫЙ|В РОТ')) fail('Rude answer set is incomplete')
if (!page.includes('ШАР|ЗАЕБАЛСЯ|ДУМАТЬ')) fail('Expanded answer set is incomplete')
if (!page.includes('ДА|ТОЧНО')) fail('Classic answers are incomplete')
if (page.includes('toggleMode')) fail('Mode selector must not exist')

console.log('Project checks passed.')
console.log('Package:', manifest.package)
console.log('Version:', manifest.versionName + ' (' + manifest.versionCode + ')')
console.log('Persistent cloud + full-screen centered answer + opacity-only answer fade enabled.')
