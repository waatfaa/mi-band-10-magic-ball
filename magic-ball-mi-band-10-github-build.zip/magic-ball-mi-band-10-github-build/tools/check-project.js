const fs = require('fs')
const path = require('path')

function fail(message) {
  console.error('ERROR: ' + message)
  process.exit(1)
}

const root = path.resolve(__dirname, '..')
const manifestPath = path.join(root, 'src', 'manifest.json')
const appPath = path.join(root, 'src', 'app.ux')
const pagePath = path.join(root, 'src', 'pages', 'index', 'index.ux')
const iconPath = path.join(root, 'src', 'common', 'images', 'icon.png')
const trianglePath = path.join(root, 'src', 'common', 'images', 'answer-triangle.png')

for (const p of [manifestPath, appPath, pagePath, iconPath, trianglePath]) {
  if (!fs.existsSync(p)) fail('Missing file: ' + path.relative(root, p))
}

const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
if (manifest.package !== 'com.magicball.band10') fail('Unexpected package name')
if (manifest.versionCode < 4) fail('versionCode must be at least 4')
if (manifest.versionName !== '1.2.0') fail('versionName must be 1.2.0')
if (!manifest.config || manifest.config.designWidth !== 212) fail('designWidth must be 212')

const features = (manifest.features || []).map(x => x.name)
for (const required of ['system.sensor', 'system.vibrator', 'system.brightness']) {
  if (!features.includes(required)) fail('Missing feature: ' + required)
}

const page = fs.readFileSync(pagePath, 'utf8')
if (!page.includes("import sensor from '@system.sensor'")) fail('Sensor import not found')
if (!page.includes("import vibrator from '@system.vibrator'")) fail('Vibrator import not found')
if (!page.includes("import brightness from '@system.brightness'")) fail('Brightness import not found')
if (!page.includes('subscribeAccelerometer')) fail('Accelerometer subscription not found')
if (!page.includes('setKeepScreenOn')) fail('Screen keep-on call not found')
if (!page.includes('REQUIRED_SHAKE_PEAKS = 5')) fail('Improved multi-shake logic not found')
if (!page.includes('SCREEN_HOLD_MS = 120000')) fail('Extended screen hold not found')
if (!page.includes('width: 244px')) fail('Oversized ball layout not found')
if (!page.includes('width: 184px')) fail('Large answer triangle not found')
if (!page.includes('answer-glow')) fail('Answer glow animation not found')
if (!page.includes('ДА ЁБАНЫЙ|В РОТ')) fail('Expanded rude answer set is incomplete')
if (!page.includes('НУ ЕГО|НАХУЙ')) fail('Original meme answers are incomplete')
if (!page.includes('ДА|ТОЧНО')) fail('Classic answers are incomplete')
if (page.includes('toggleMode')) fail('Mode selector must not exist')
if (page.includes('MAGIC BALL')) fail('Extra title text must not exist in UI')

console.log('Project checks passed.')
console.log('Package:', manifest.package)
console.log('Version:', manifest.versionName + ' (' + manifest.versionCode + ')')
console.log('XL ball + improved multi-stage animation + expanded mixed answer pool enabled.')
