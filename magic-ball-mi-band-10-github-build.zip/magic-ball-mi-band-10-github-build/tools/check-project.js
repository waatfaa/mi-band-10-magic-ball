const fs = require('fs')
const path = require('path')

function fail(message) {
  console.error('ERROR: ' + message)
  process.exit(1)
}

const root = path.resolve(__dirname, '..')
const manifestPath = path.join(root, 'src', 'manifest.json')
const appPath = path.join(root, 'src', 'app.ux')
const pagePath = path.join(root, 'src', 'pages', 'index', 'index.ux')
const iconPath = path.join(root, 'src', 'common', 'images', 'icon.png')

for (const p of [manifestPath, appPath, pagePath, iconPath]) {
  if (!fs.existsSync(p)) fail('Missing file: ' + path.relative(root, p))
}

const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
if (manifest.package !== 'com.magicball.band10') fail('Unexpected package name')
if (manifest.versionCode < 2) fail('versionCode must be at least 2')
if (!manifest.config || manifest.config.designWidth !== 212) fail('designWidth must be 212 for the 212 px design draft')

const features = (manifest.features || []).map(x => x.name)
for (const required of ['system.sensor', 'system.vibrator']) {
  if (!features.includes(required)) fail('Missing feature: ' + required)
}

const page = fs.readFileSync(pagePath, 'utf8')
if (!page.includes("import sensor from '@system.sensor'")) fail('Sensor import not found')
if (!page.includes("import vibrator from '@system.vibrator'")) fail('Vibrator import not found')
if (!page.includes('subscribeAccelerometer')) fail('Accelerometer subscription not found')
if (!page.includes('vibrator.vibrate')) fail('Vibration call not found')
if (!page.includes('НУ ЕГО|НАХУЙ')) fail('Meme answer set is incomplete')

console.log('Project checks passed.')
console.log('Package:', manifest.package)
console.log('Version:', manifest.versionName + ' (' + manifest.versionCode + ')')
console.log('designWidth:', manifest.config.designWidth)
